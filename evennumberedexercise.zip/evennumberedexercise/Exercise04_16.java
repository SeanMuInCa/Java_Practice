public class Exercise04_16 {
  public static void main(String[] args) {
    char ch = (char)(Math.random() * 26 + 'A');
    System.out.println("A random uppercase letter is " + ch);
  }
}